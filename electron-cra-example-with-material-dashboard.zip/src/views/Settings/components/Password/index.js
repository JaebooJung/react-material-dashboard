export { default } from './Password';
