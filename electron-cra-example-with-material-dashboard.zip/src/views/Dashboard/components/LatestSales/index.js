export { default } from './LatestSales';
