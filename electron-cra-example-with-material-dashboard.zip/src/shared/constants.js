// Electron doesn't support export default { ... } syntax.
module.exports = {
  channels: {
    APP_INFO: "app_info",
  },
};
